## Interviews

### What do you hope to learn from these interviews?
I hope to learn about how a prospective user would want to use an interface to manage their daily spiritual time. I want to know what features should be included and how I can help them with their needs.

### Questions:

- **What are some activities you do when doing daily spiritual time?**
  - Olivia:
  - Carson:

- **What are some needs around seeing your previous entries?**
  - Olivia:
  - Carson:

- **How often would you view previous entries?**
  - Olivia:
  - Carson:

- **What specifically do you want to track?**
  - Olivia:
  - Carson:

- **What do you usually journal on?**
  - Olivia:
  - Carson:

- **Would you prefer a minimalist or feature-rich application?**
  - Olivia:
  - Carson:

- **What types of goals would you set for yourself using a tool like this?**
  - Olivia:
  - Carson:

- **What are your favorite themes to use? (dark mode, light mode, a color, etc.)**
  - Olivia:
  - Carson:

### Findings (What did you learn from them?)
- 

## Design Goals and Requirements

- To address in implementation
- Future Work

## Sketching Design Alternatives

- **Choose 3 interesting design challenges to explore.**
  - TODO

- **10-plus-10 sketches**
  - TODO

## Prototype Sketch of Your Envisioned Interface

- TODO

## Feedback for Prototype Sketches from 2 People

- Olivia: TODO
- Carson: TODO

## Mock User Profile

- Brief description of them.
- How they would use this application.
